﻿namespace RChang_Lab_3_CPT_206
{
	partial class detailFrm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblStateName = new System.Windows.Forms.Label();
			this.lblPopulation = new System.Windows.Forms.Label();
			this.lblFlagDescription = new System.Windows.Forms.Label();
			this.lblFlower = new System.Windows.Forms.Label();
			this.lblBird = new System.Windows.Forms.Label();
			this.lblThreeLargestCities = new System.Windows.Forms.Label();
			this.lblCapital = new System.Windows.Forms.Label();
			this.lblColors = new System.Windows.Forms.Label();
			this.lblMedianIncome = new System.Windows.Forms.Label();
			this.lblComputerJobsPercentage = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblStateName
			// 
			this.lblStateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStateName.Location = new System.Drawing.Point(189, 9);
			this.lblStateName.Name = "lblStateName";
			this.lblStateName.Size = new System.Drawing.Size(379, 61);
			this.lblStateName.TabIndex = 0;
			this.lblStateName.Text = "label1";
			this.lblStateName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPopulation
			// 
			this.lblPopulation.Location = new System.Drawing.Point(21, 70);
			this.lblPopulation.Name = "lblPopulation";
			this.lblPopulation.Size = new System.Drawing.Size(278, 26);
			this.lblPopulation.TabIndex = 1;
			this.lblPopulation.Text = "label1";
			// 
			// lblFlagDescription
			// 
			this.lblFlagDescription.Location = new System.Drawing.Point(21, 117);
			this.lblFlagDescription.Name = "lblFlagDescription";
			this.lblFlagDescription.Size = new System.Drawing.Size(278, 26);
			this.lblFlagDescription.TabIndex = 3;
			this.lblFlagDescription.Text = "label1";
			// 
			// lblFlower
			// 
			this.lblFlower.Location = new System.Drawing.Point(21, 156);
			this.lblFlower.Name = "lblFlower";
			this.lblFlower.Size = new System.Drawing.Size(278, 26);
			this.lblFlower.TabIndex = 4;
			this.lblFlower.Text = "label1";
			// 
			// lblBird
			// 
			this.lblBird.Location = new System.Drawing.Point(21, 196);
			this.lblBird.Name = "lblBird";
			this.lblBird.Size = new System.Drawing.Size(278, 26);
			this.lblBird.TabIndex = 5;
			this.lblBird.Text = "label1";
			// 
			// lblThreeLargestCities
			// 
			this.lblThreeLargestCities.Location = new System.Drawing.Point(21, 280);
			this.lblThreeLargestCities.Name = "lblThreeLargestCities";
			this.lblThreeLargestCities.Size = new System.Drawing.Size(278, 26);
			this.lblThreeLargestCities.TabIndex = 6;
			this.lblThreeLargestCities.Text = "label1";
			// 
			// lblCapital
			// 
			this.lblCapital.Location = new System.Drawing.Point(21, 315);
			this.lblCapital.Name = "lblCapital";
			this.lblCapital.Size = new System.Drawing.Size(278, 26);
			this.lblCapital.TabIndex = 7;
			this.lblCapital.Text = "label1";
			// 
			// lblColors
			// 
			this.lblColors.Location = new System.Drawing.Point(21, 239);
			this.lblColors.Name = "lblColors";
			this.lblColors.Size = new System.Drawing.Size(278, 26);
			this.lblColors.TabIndex = 8;
			this.lblColors.Text = "label1";
			// 
			// lblMedianIncome
			// 
			this.lblMedianIncome.Location = new System.Drawing.Point(21, 357);
			this.lblMedianIncome.Name = "lblMedianIncome";
			this.lblMedianIncome.Size = new System.Drawing.Size(278, 26);
			this.lblMedianIncome.TabIndex = 9;
			this.lblMedianIncome.Text = "label1";
			// 
			// lblComputerJobsPercentage
			// 
			this.lblComputerJobsPercentage.Location = new System.Drawing.Point(21, 399);
			this.lblComputerJobsPercentage.Name = "lblComputerJobsPercentage";
			this.lblComputerJobsPercentage.Size = new System.Drawing.Size(278, 26);
			this.lblComputerJobsPercentage.TabIndex = 10;
			this.lblComputerJobsPercentage.Text = "label1";
			// 
			// detailFrm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ControlDark;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.lblComputerJobsPercentage);
			this.Controls.Add(this.lblMedianIncome);
			this.Controls.Add(this.lblColors);
			this.Controls.Add(this.lblCapital);
			this.Controls.Add(this.lblThreeLargestCities);
			this.Controls.Add(this.lblBird);
			this.Controls.Add(this.lblFlower);
			this.Controls.Add(this.lblFlagDescription);
			this.Controls.Add(this.lblPopulation);
			this.Controls.Add(this.lblStateName);
			this.Name = "detailFrm";
			this.Text = "detailFrm";
			this.Load += new System.EventHandler(this.detailFrm_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lblStateName;
		private System.Windows.Forms.Label lblPopulation;
		private System.Windows.Forms.Label lblFlagDescription;
		private System.Windows.Forms.Label lblFlower;
		private System.Windows.Forms.Label lblBird;
		private System.Windows.Forms.Label lblThreeLargestCities;
		private System.Windows.Forms.Label lblCapital;
		private System.Windows.Forms.Label lblColors;
		private System.Windows.Forms.Label lblMedianIncome;
		private System.Windows.Forms.Label lblComputerJobsPercentage;
	}
}