﻿namespace RChang_Lab_3_CPT_206
{


	partial class StateInformationDataSet
	{
	}
}

namespace RChang_Lab_3_CPT_206.StateInformationDataSetTableAdapters {
    
    
    public partial class StatesTableAdapter {
    }
}
